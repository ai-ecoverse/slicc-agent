---
name: deploy-notes
description: How this project deploys.
---

Run ./deploy.sh from the workspace.
