# Shared

The user prefers short answers.
