#!/bin/sh
set -e
echo deploy
